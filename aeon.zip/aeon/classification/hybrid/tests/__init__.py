"""Tests for time series classifiers."""
