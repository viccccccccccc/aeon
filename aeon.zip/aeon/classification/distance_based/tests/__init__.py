"""Distance based test code."""
