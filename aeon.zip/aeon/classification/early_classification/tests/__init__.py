"""Early classification test code."""
