"""Tests for deep learning classifiers."""
