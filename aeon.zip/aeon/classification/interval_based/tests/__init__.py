"""Tests for interval based classifiers."""
