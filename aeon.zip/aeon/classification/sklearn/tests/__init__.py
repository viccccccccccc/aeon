"""sklearn classifier test code."""
