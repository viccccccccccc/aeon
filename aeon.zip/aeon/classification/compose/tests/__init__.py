"""Tests for classification composable estimators."""
