"""Tests for benchmarking."""
