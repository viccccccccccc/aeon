"""Tests for anomaly detection."""
