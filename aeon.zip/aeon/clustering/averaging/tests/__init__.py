"""Tests for clustering metrics."""
