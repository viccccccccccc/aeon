"""Tests for clustering."""
