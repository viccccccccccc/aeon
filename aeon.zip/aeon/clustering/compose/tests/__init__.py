"""Tests for regression composable estimator."""
