"""Compositions for clusterers."""

__all__ = [
    "ClustererPipeline",
]

from aeon.clustering.compose._pipeline import ClustererPipeline
