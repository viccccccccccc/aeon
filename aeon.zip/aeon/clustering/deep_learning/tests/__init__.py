"""Deep learning clustering tests."""
