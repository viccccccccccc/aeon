"""Conversion auxiliary utilities."""
