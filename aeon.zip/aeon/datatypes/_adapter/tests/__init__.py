"""Tests for pandas/dask conversion adapters."""
