"""Testing for hybrid base classes."""
