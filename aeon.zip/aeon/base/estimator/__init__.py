"""Base classes for estimators which are part of multiple aeon modules."""
