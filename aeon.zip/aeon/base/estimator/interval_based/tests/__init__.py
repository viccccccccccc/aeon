"""Testing for interval-based base classes."""
