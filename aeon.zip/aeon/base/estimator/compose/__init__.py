"""Base class for composable estimators."""
