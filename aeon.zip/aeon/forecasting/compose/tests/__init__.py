"""Tests for forecasting compose."""
