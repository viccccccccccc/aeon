"""Implements BATS algorithm.

BATS refers to Exponential smoothing state space model with Box-Cox
transformation, ARMA errors, Trend and Seasonal components.

Wrapping implementation in [1]_ of method proposed in [2]_.
"""

__maintainer__ = []
__all__ = ["BATS"]

from aeon.forecasting.base.adapters import _TbatsAdapter


class BATS(_TbatsAdapter):
    """BATS forecaster for time series with multiple seasonality.

    Wrapping implementation in [1]_ of method proposed in [2]_. See [3]_
    for blogpost by a creator of [1]_ giving brief explanation of the BATS
    model. See [4]_ for discussion on multiple seasonalities and discussion of
    how BATS compares with some other approaches.

    BATS is acronym for:

    - Box-Cox transformation
    - ARMA errors
    - Trend
    - Seasonal components

    BATS was designed to forecast time series with multiple seasonal
    periods. For example, daily data may have a weekly pattern as well
    as an annual pattern. Or hourly data can have three seasonal periods:
    a daily pattern, a weekly pattern, and an annual pattern.

    In BATS, a Box-Cox transformation is applied to the original time series,
    and then this is modelled as a linear combination of an exponentially
    smoothed trend, a seasonal component and an ARMA component. BATS
    conducts some hyper-parameter tuning (e.g. which of these components to
    keep and which to discard) using AIC.

    Parameters
    ----------
    use_box_cox: bool or None, default=None
        If Box-Cox transformation of original series should be applied.
        When None both cases shall be considered and better is selected by AIC.
    box_cox_bounds: tuple, shape=(2,), default=(0, 1)
        Minimal and maximal Box-Cox parameter values.
    use_trend: bool or None, default=None
        Indicates whether to include a trend or not.
        When None both cases shall be considered and better is selected by AIC.
    use_damped_trend: bool or None, default=None
        Indicates whether to include a damping parameter in the trend or not.
        Applies only when trend is used.
        When None both cases shall be considered and better is selected by AIC.
    sp: Iterable or array-like of floats, default=None
        Abbreviation of "seasonal periods". The length of each of the periods
        (amount of observations in each period). Accepts int and float values here.
        When None or empty array, non-seasonal model shall be fitted.
    use_arma_errors: bool, default=True
        When True BATS will try to improve the model by modelling residuals with ARMA.
        Best model will be selected by AIC.
        If False, ARMA residuals modeling will not be considered.
    show_warnings: bool, default=True
        If warnings should be shown or not.
        Also see Model.warnings variable that contains all model related warnings.
    n_jobs: int, default=None
        How many jobs to run in parallel when fitting BATS model.
        When not provided BATS shall try to utilize all available cpu cores.
    multiprocessing_start_method: str, default='spawn'
        How threads should be started. See also:
        https://docs.python.org/3/library/multiprocessing.html#contexts-and-start-methods
    context: abstract.ContextInterface, default=None
        For advanced users only. Provide this to override default behaviors

    See Also
    --------
    TBATS

    References
    ----------
    .. [1] https://github.com/intive-DataScience/tbats
    .. [2] De Livera, A.M., Hyndman, R.J., & Snyder, R. D. (2011),
       Forecasting time series with complex seasonal patterns using exponential
       smoothing, Journal of the American Statistical Association, 106(496), 1513-1527.
       DOI: https://doi.org/10.1198/jasa.2011.tm09771
    .. [3] G. Skorupa. Multiple Seasonalities using TBATS in Python.
       https://medium.com/intive-developers/forecasting-time-series-with-multiple-seasonalities-using-tbats-in-python-398a00ac0e8a
    .. [4] R.J. Hyndman, G. Athanasopoulos. Forecasting: Principles and Practice.
       https://otexts.com/fpp2/complexseasonality.html

    Examples
    --------
    >>> from aeon.datasets import load_airline
    >>> from aeon.forecasting.bats import BATS
    >>> y = load_airline()
    >>> forecaster = BATS(  # doctest: +SKIP
    ...     use_box_cox=False,
    ...     use_trend=False,
    ...     use_damped_trend=False,
    ...     sp=12,
    ...     use_arma_errors=False,
    ...     n_jobs=1)
    >>> forecaster.fit(y)  # doctest: +SKIP
    BATS(...)
    >>> y_pred = forecaster.predict(fh=[1,2,3])  # doctest: +SKIP
    """  # noqa: E501

    _fitted_param_names = "aic"

    def _create_model_class(self):
        """Create model class."""
        # both bats and tbats inherit the same interface from the base class and only
        # instantiate a different model class internally
        from tbats import BATS as _BATS

        self._ModelClass = _BATS

    @classmethod
    def get_test_params(cls, parameter_set="default"):
        """Return testing parameter settings for the estimator.

        Parameters
        ----------
        parameter_set : str, default="default"
            Name of the set of test parameters to return, for use in tests. If no
            special parameters are defined for a value, will return `"default"` set.

        Returns
        -------
        params : dict or list of dict
        """
        params1 = {
            "use_box_cox": False,
            "use_trend": False,
            "use_damped_trend": False,
            "sp": [],
            "use_arma_errors": False,
            "n_jobs": 1,
        }

        return [params1]
