"""Tests for the forecaster base module."""
