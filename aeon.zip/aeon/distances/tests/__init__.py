"""Tests for distance module."""
